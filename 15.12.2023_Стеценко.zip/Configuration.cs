﻿struct Configuration
{
    public string telegramToken;
    public string daDataToken;
}

